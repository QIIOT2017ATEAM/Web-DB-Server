<?php

echo "<strong>Hello World</strong>\n";
