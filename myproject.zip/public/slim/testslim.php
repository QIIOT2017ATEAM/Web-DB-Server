<?php
require 'vendor/autoload.php';

echo "success";
?>